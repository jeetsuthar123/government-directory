import { IsBoolean, IsMongoId, IsOptional, IsString, MaxLength, MinLength } from 'class-validator';
export class BlockDto {
  @IsMongoId() districtId!: string;
  @IsString() @MinLength(2) @MaxLength(150) name!: string;
  @IsOptional() @IsString() @MaxLength(30) code?: string;
  @IsOptional() @IsBoolean() isActive?: boolean;
}